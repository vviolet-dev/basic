#!/bin/sh
picom &
nm-applet & 
dunst & 
flameshot &

